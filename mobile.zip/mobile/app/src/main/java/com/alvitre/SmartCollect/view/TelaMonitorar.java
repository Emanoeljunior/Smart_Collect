package com.alvitre.SmartCollect.view;

import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;

import com.alvitre.SmartCollect.R;

public class TelaMonitorar extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_tela_monitorar);
    }
}
